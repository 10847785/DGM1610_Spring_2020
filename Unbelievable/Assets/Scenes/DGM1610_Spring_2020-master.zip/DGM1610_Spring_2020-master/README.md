# DGM1610_Spring_2020
Personal class repository for spring 2020
